# Introdução ao git
Usaremos este projeto para aprender os comandos básicos do git. Sua missão é criar um Pull Request contendo um site que apresenta o seu currículo.
Para isso, você deverá:

1. Escolher um [template](http://trendytheme.net/20-best-free-html-resume-templates-to-download/).
2. Fazer um fork deste projeto
3. Clonar o seu fork no cloud9
4. Baixar o template no cloud9
5. Fazer o commit do template
6. Customizar o template com os seus dados
7. Fazer o commit das suas alterações
8. Fazer o push das sua alterações para o github
9. Abrir o pull request


